<template>
  <div>
    <b-container>
      <b-row>
        <div class="dashboard-title text-center mb-70 mt-30">
          <h2 class="mb-10"> গাইডলাইন</h2>
          <!-- <p>নিছে বর্ণিত নিয়মাবলী পড়ুন ।</p> -->
        </div>
      </b-row>

      <b-row>
        <div class="col-md-12">

          <div class="terms">
            <div class="title  pb-0">
              <h3>জিতে যাও কী ?</h3>
            </div>
            <div class="details  pt-10">
              <p>জিতে যাও বাংলাদেশের প্রথম ডিমান্ড বেইজড মার্কেটপ্লেস যেখানে একজন কাস্টমার নিজের প্রয়োজনীয় যেকোনো প্রোডাক্ট কিনতে পোস্ট (ডিমান্ড পোস্ট) করবে। আবার সেলাররা সেইসব পোস্টে নিজেদের সুবিধামত প্রাইস দিয়ে বিড করবে। </p> 

              <p>সেলারদের বিড গুলো দেখে কাস্টমার কিছু বিড কে শর্ট লিস্ট করবে। তারপর সেই সব শর্ট লিস্টেড সেলারদের মধ্য থেকে একজনকে ফাইনালি কনফার্ম করবে। এভাবেই কাস্টমার এবং সেলার দুইজনই জিতে যাবে।</p>  

              <p> মজার ব্যাপার হলো <a href="http://jitejao.com" target="_blank">jitejao.com</a> এ সবাই কাস্টমার আবার সবাই সেলার। অর্থাৎ এক একাউন্টেই ডিমান্ড পোস্ট ও করতে পারবে আবার অন্যের পোস্টে বিড ও করতে পারবে।</p>
            </div>
          </div>

          <div class="terms">
            <div class="title  pb-0">
              <h3>কীভাবে কাজ করে ?</h3>
            </div>
            <div class="details  pt-10">
              <p><a href="http://jitejao.com" target="_blank">jitejao.com</a> এমন একটা প্লাটফর্ম যেখানে একজন কাস্টমার নিজের যে কোনো প্রয়োজনীয় প্রোডাক্টের জন্য পোস্ট করতে পারে। সেটা নতুন ও হতে পারে আবার পুরোনো ও হতে পারে। খুচরা ও হতে পারে আবার পাইকারি ও হতে পারে। </p> 
              <p>সেই পোস্টে যে কেউ বিড করতে পারবে। এখানে বিড হলো এক ধরণের অফার। এই বিড গুলো থেকে কাস্টমার প্রথমে এক বা একাধিক জনকে শর্টলিস্টেড করবে এবং পরে তাদের সাথে যোগাযোগ একজনকে কনফার্ম বা বিজয়ী করবে।</p>  
            </div>
          </div>

          <div class="terms">
            <div class="title  pb-0">
              <h3>কীভাবে ডিমান্ড করবেন?</h3>
            </div>
            <div class="details  pt-10">
              <p>ডিমান্ড পোস্ট করতে প্রথমে ''পোস্ট করুন'' বাটনে ক্লিক করুন। তারপর খুব সহজেই ফিল্ড গুলো fill up করুন। এরপর সাবমিট করুন। ব্যস, আপনার পোস্ট হয়ে গেলো। এবার সেলারদের থেকে বিডের জন্য অপেক্ষা করুন।</p> 
            </div>
          </div>

          <div class="terms">
            <div class="title  pb-0">
              <h3>কীভাবে বিড করবেন?</h3>
            </div>
            <div class="details  pt-10">
              <p>বিড করতে  যেকোনো পোস্টের বিড করুন বাটনে ক্লিক করুন। তারপর খুব সহজেই আপনার অফারসহ ফিল্ড গুলো fill up করুন। এরপর সাবমিট করুন। ব্যস, আপনার বিড হয়ে গেলো। এবার দেখুন কাস্টমার আপনার বিড শর্ট লিস্ট কিংবা কনফার্ম করে কিনা।</p> 
            </div>
          </div>

          <div class="terms">
            <div class="title  pb-0">
              <h3>কীভাবে ব্যাজ পাবেন ?</h3>
            </div>
            <div class="details  pt-10">
              <p><a href="http://jitejao.com" target="_blank">jitejao.com</a> এ সব ইউজারই ভেরিফায়েড। নিজের নাম্বার দিয়ে রেজিস্ট্রেশন এবং লগইন করার পর একজন ইউজার ভেরিফায়েড হয়ে যাবে। ভেরিফায়েড হওয়ার সময় তিনি সিলভার ব্যাজ পাবেন। এরপর ১০ টি পোস্ট কমপ্লিট হলে পাবেন গ্রীন ব্যাজ। আবার সবমিলিয়ে ৩০ টি পোস্ট কমপ্লিট হলে পাবেন  পিঙ্ক ব্যাজ।</p>
              <p>একইভাবে ৫ টি বিড বা সাপ্লাই কমপ্লিট হলে পাবেন গ্রীন ব্যাজ। আবার সবমিলিয়ে ১৫টি পোস্ট কমপ্লিট হলে পাবেন পিঙ্ক ব্যাজ।</p> 
              <p>ভবিষ্যতে এই ব্যাজ অনুযায়ী একজন ইউজারকে সুযোগ সুবিধা দেয়া হবে।</p>
            </div>
          </div>

          <div class="terms">
            <div class="title  pb-0">
              <h3>সাবস্ক্রিপশন কী ?</h3>
            </div>
            <div class="details  pt-10">
              <p> <a href="http://jitejao.com" target="_blank">jitejao.com</a> এ সারা মাস আনলিমিটেড বিড করতে হলে সাবস্ক্রিপশন কিনতে হবে। ৩০ টাকায় ১ মাস। এছাড়া আরও কিছু প্যাকেজ রয়েছে। তবে রেজিস্ট্রেশন করলেই প্রথম মাস সাবস্ক্রিপশন ফ্রি।</p>
            </div>
          </div>


        </div>
      </b-row>
    </b-container>
    <Footer />
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
};
</script>

<style scoped>
  .terms .title{
    margin-top: 30px;
  }
  .terms .details a{
    color: #B90D59;
  }
  .terms  p{
    font-size:18px;
  }
.collapsed::after {
  content: "\f054";
  font-family: "Font Awesome 5 Pro" !important;
  float: right;
}
.not-collapsed::after {
  content: "\f054";
  font-family: "Font Awesome 5 Free" !important;
}
.not-collapsed {
  background-color: #da2d75 !important;
}
.not-collapsed span {
  color: #fff !important;
}
/* .collapsed{
    border-top:inherit !important;
} */
.accordion-custom {
  border: 1px solid #ddd;
}
.faq-title {
  border-radius: 0;
  border-bottom: 1px solid #ddd;
}

.faq-title span {
  font-size: 18px;
}
.faq-details .details {
  border-bottom: 1px solid #ddd;
}
</style>