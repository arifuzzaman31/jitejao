<template>
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-12">
              <NuxtLink to="/">sfasd</NuxtLink>
            </div>
            <div class="col-lg-4 col-sm-12">
                 dfd   dfd   dfd 
            </div>
            <div class="col-lg-4 col-sm-12">
                dfd
            </div>
            
        </div>
    </div>
</template>