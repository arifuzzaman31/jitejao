<template>
    <b-container >

        <b-row>
            <div class="col-md-4">
                <div class="my-demand-post-list bg-white mt-30 bg-shadow-card">
                    <div class="demand-post-list p15">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>10005885৳</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                       <span class=" bg-green-op-10 color-green post-status">Progress</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                            <span class="bg-gray color-dark"  v-b-tooltip.hover title="এডিট "><i class="fas fa-edit"></i></span>
                           <span class="bg-gray color-dark"  v-b-tooltip.hover title="ডিলিট"><i class="fas fa-trash"></i></span>
                          <span class="bg-gray color-dark"  v-b-tooltip.hover title="ম্যানেজ"><i class="fas fa-list"></i></span>
                          
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
             <div class="col-md-4">
                <div class="my-demand-post-list bg-white mt-30 bg-shadow-card">
                    <div class="demand-post-list p15">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>10005885৳</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                       <span class=" bg-green-op-10 color-green post-status">Progress</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                          <span class="bg-gray color-dark"  v-b-tooltip.hover title="ম্যানেজ"><i class="fas fa-list"></i>
                           <span class="badge-number bg-red color-white" >10</span>
                          </span>
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
            <div class="col-md-4">
                <div class="my-demand-post-list bg-white mt-30 bg-shadow-card">
                    <div class="demand-post-list p15">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>10005885৳</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                        <span class=" bg-purple-op-10 color-purple post-status">Complete</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                           <span class="bg-purple color-white" v-b-tooltip.hover title="এই ডিমান্ডটি জয়ী হয়েছেন" v-b-modal.modal-center><i class="fas fa-trophy"></i></span>
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
        </b-row>
        

        
        <b-row>
            <div class="col-md-4">
                <div class="my-demand-post-list bg-white  mt-30 bg-shadow-card">
                   <div class="demand-post-list p15 border-0">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>1000BDT</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class="my-demand-post-btn p10 pl-10 pr-10 bg-purple-op-10" >
                     <div class="my-demand-post-bid ">
                        <!-- <span class="fw-600">আমার বিড:</span> -->
                        <span>অফার: 100058৳</span>
                        <span>ডেডলাইন: 10 OCT 2021</span>
                        <span class="bg-blue-op-20 color-blue btn-my-bid">Details</span>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                        <span class=" bg-green-op-10 color-green post-status">Progress</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                          <span class="bg-gray color-dark"  v-b-tooltip.hover title="এডিট "><i class="fas fa-edit"></i></span>
                          <span class="bg-gray color-dark"  v-b-tooltip.hover title="ডিলিট"><i class="fas fa-trash"></i></span>
                          <span class="bg-gray color-dark"  v-b-tooltip.hover title="ম্যানেজ"><i class="fas fa-list"></i></span>
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
                  <div class="col-md-4">
                <div class="my-demand-post-list bg-white  mt-30 bg-shadow-card">
                   <div class="demand-post-list p15 border-0">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>1000BDT</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class="my-demand-post-btn p10 pl-10 pr-10 bg-purple-op-10" >
                     <div class="my-demand-post-bid ">
                        <!-- <span class="fw-600">আমার বিড:</span> -->
                        <span>অফার: 100058৳</span>
                        <span>ডেডলাইন: 10 OCT 2021</span>
                        <span class="bg-blue-op-20 color-blue btn-my-bid">Details</span>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                        <span class=" bg-green-op-10 color-green post-status">Progress</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                           <span class="bg-gray color-dark" v-b-tooltip.hover title="আপনি শর্টলিস্টেড হয়েছেন । সেলারের সাথে যোগাযোগ করুন"><i class="fas fa-phone"></i></span>
                          <span class="bg-gray color-dark" v-b-tooltip.hover title="ম্যানেজ"><i class="fas fa-list"></i></span>
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
                  <div class="col-md-4">
                <div class="my-demand-post-list bg-white  mt-30 bg-shadow-card">
                    <div class="demand-post-list border-0 p15">
                        <div class="img float-l mr-15">
                        <img src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg" alt="author" class="img-fluid " width="50">
                        </div>
                        <div class="content">
                       <h6>আমার ১০০ পিস টিশার্ট লাগবে ...</h6>
                        <p><span>বাজেট: </span>100000৳</p>
                        <p class="date"><span>ডেডলাইন:</span> 10 OCT 2021</p>
                        </div>
                    </div>
                    <div class="my-demand-post-btn p10 pl-10 pr-10 bg-purple-op-10" >
                        <div class="my-demand-post-bid ">
                        <!-- <span class="fw-600">আমার বিড:</span> -->
                        <span>অফার: 100058৳</span>
                        <span>ডেডলাইন: 10 OCT 2021</span>
                        <span class="bg-blue-op-20 color-blue btn-my-bid">Details</span>
                        </div>
                    </div>
                    <div class=" my-demand-post-btn p10 pl-10 pr-10" >
                        <div class="my-demand-post-status ">
                       <span class=" bg-purple-op-10 color-purple post-status">Complete</span>
                        </div>
                       <div class="my-demand-post-manage-btn">
                          <span class="bg-purple color-white" v-b-tooltip.hover title="আপনি এই বিডটি বিজয়ী করেছেন" v-b-modal.modal-center1><i class="fas fa-trophy"></i></span>
                       </div>
                    </div>
                </div>
            </div>
            <!-- end -->
        </b-row>

<div>
   <b-modal id="modal-center1" centered title="আমার বিড" hide-footer>
       <b-row>
        <div class="col-md-12">
          <div
            class="nilam-title w-100 mt-30" >
            <div class="nilam-winner w-100 bg-white p20 clearfix">
                <div class="winner-name text-center">
                  <div class="">
                    <img
                      class="img-fluid author-img winner-img text-center"
                      src="https://api.bidodevs.xyz/bido/public/images/demand/big/4_demand_6129cf6ea357a.jpeg"
                    />
                  </div>
                  <div class="content mt-10">
                        <p><span class="fw-600">এমাউন্ট: </span>10005885৳</p>
                        <p><span class="fw-600">ডেলিভারির তারিখ:</span> 10 OCT 2021</p>
                        <p><span class="fw-600">বিস্তারিত: </span>আমার ১০০ পিস টিশার্ট লাগবে ?</p>
                  </div>
                    <div class="demand-rating">
                       <h6 class="fw-600 mt-10"> আমার রেটিং</h6>
                      st
                  </div>
                  <div class="">
                       <h6 class="fw-600 mt-10"> বায়ার রেটিং</h6>
                      <button data-v-bd97be92="" class="button button-sm color-yellow bg-yellow-op-20 mt-2">
                         বায়ারকে রিভিউ দিন
                        </button>
                        <div>st</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </b-row>
      </b-modal>
      </div>



<div>
  <b-modal id="modal-center" centered title="ডিমান্ডটি  জয়ী হয়েছেন" >
        <div class="col-md-12">
          <div
            class="nilam-title w-100 mt-15" >

            <div class="nilam-winner w-100 bg-white p20 clearfix">
                <div class="winner-name text-center">
                  <div class="">
                    <img
                      class="img-fluid author-img winner-img text-center"
                      src="http://192.168.0.17:3000/_nuxt/assets/images/testimonial/1.jpg"
                    />
                    <h2 class="text-bold mt-10">
                     Mizanur Rahman
                    </h2>
                    <p class="mb-20"> যোগাযোগঃ<a  href="tel:01834394216">01834394216</a></p>
                  </div>
                  <div class="content mt-10">
                      <h4 class="fw-600 mb-10">বিড ডিটেইলস </h4>
                        <p><span class="fw-600">Price: </span>10005885৳</p>
                        <p><span class="fw-600">Date:</span> 10 OCT 2021</p>
                        <p><span class="fw-600">Description: </span>আমার ১০০ পিস টিশার্ট লাগবে ?</p>
                  </div>
                  <div class="demand-rating">
                       <h4 class="fw-600 mt-10"> আমার রেটিং</h4>
                      
                  </div>
                  <div class="">
                       <h4 class="fw-600 mt-10"> সেলার রেটিং</h4>
                      <button data-v-bd97be92="" class="button button-sm color-yellow bg-yellow-op-20 mt-2">
                         সেলার কে রিভিউ দিন
                        </button>
                        <div>st</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
  </b-modal>
</div>




    </b-container>              
        </template>

        
<script>
export default {
  data() {
    return {
        
    }
  }
}
</script>

        <style>
        body{
            background-color: #F2F3F9;
        }
        .my-demand-post-list{
            border-radius: 5px;
        }
        .my-demand-post-list .demand-post-list{
            border-bottom: 1px solid #F2F3F9;
        }
        .my-demand-post-list .img{
            height: 50px;
            width: 50px;
            object-fit: cover;
        }
        .my-demand-post-list .img img{
            border-radius: 5px;
        }
        .my-demand-post-list .content h6{
            height: 19px;
            overflow: hidden;
            font-weight: bold;
        }
        .my-demand-post-list .content .date{
            margin-top: -5px;
        }
        .my-demand-post-btn{
            display: flex;
        }
        .my-demand-post-status{
            flex: 1;
        } 
        .my-demand-post-status span.post-status{
            border-radius: 50px;
            padding: 0px 10px 0px 10px;
            font-size: 14px
        }
        .my-demand-post-bid span{
             border-radius: 50px;
            padding: 0px 6px 0px 0px;
            font-size: 15px
        }
        .my-demand-post-bid span.btn-my-bid{
            padding: 0px 10px 0px 10px;
        }
        .my-demand-post-manage-btn span{
               display: inline-block;
                width: 30px;
                height: 30px;
                text-align: center;
                line-height:32px;
                border-radius: 50px;
                font-size: 12px;
                position: relative;
        }   
        .my-demand-post-manage-btn span.badge-number{
                position: absolute;
                font-size: 10px;
                top: -16px;
                left: 9px;
                width: 20px;
                height: 20px;
                line-height: 22px;
        }
        .bg-shadow-card{
            box-shadow: 0 3px 9px 0 rgba(169, 184, 200, .15);
        }
        .my-demand-post-manage-btn span{
           margin-right: 10px;
        }
        .my-demand-post-manage-btn span:last-child{
            margin-right: 0;
        }
        
        </style>