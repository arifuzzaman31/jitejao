<template>
  <b-container>
    <b-row>
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
      <div class="col-md-3">
        <div class="category-list mt-30 mb-30">
          <div class="post-author">
            <NuxtLink to="">
              <!-- <img
                class="img-fluid rounded-circle author-img"
                src="~/assets/images/user/"
                alt=""
              /> -->
            </NuxtLink>
            <span>Arifuzzaman</span>
            <div class="float-r">
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/1.png"
                v-b-tooltip.hover
                title="ভেরিফাইড বায়ার"
                alt="author badge"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/2.png"
                alt="author badge"
                v-b-tooltip.hover
                title="১০ এর অধিক কাজ করিয়েছেন"
              />
              <img
                class="img-fluid cate-badge"
                src="~/assets/images/badge/3.png"
                alt="author badge"
                v-b-tooltip.hover
                title="৫০  এর অধিক কাজ করিয়েছেন"
              />
            </div>
          </div>
          <!-- end author -->
          <div class="post-image bg-white">
            <NuxtLink to="">
              <img
                class="img-fluid"
                src="http://192.168.31.68/demand-back/public/images/demand/default/big.jpg"
                alt=""
              />
              <!-- <img
                    v-else
                    class="img-fluid"
                    :src="demand.default_big_image"
                    :alt="demand.title"
                    /> -->
            </NuxtLink>
          </div>
          <!-- post image -->
          <div class="content clearfix">
            <div class="title">
              <NuxtLink to=""
                ><h3>আপনার জন্য অপেক্ষা করছে শতাধিক বিক্রেতা</h3></NuxtLink
              >
            </div>
            <div class="nilam-price-cate price-item display-f">
              <div class="item color-green bg-green-op-10 text-center">
                <p class="color-green">সর্বোচ্চ বিড</p>
                <p class="color-green font-weight-bold">২৫৫ পয়েন্ট</p>
              </div>
              <div class="item color-purple bg-purple-op-20 text-center">
                <p class="color-purple">বেস প্রাইস</p>
                <p class="color-purple font-weight-bold">৬৯৯ পয়েন্ট</p>
              </div>
            </div>
            <div class="nilam-hrbid-cate price-item">
              <span class="item color-black"> 0d : 21h : 29m : 0s</span>
              <span class="price float-r olor-black"> <b>30</b> বিড</span>
            </div>
            <div class="cate-btn">
              <NuxtLink
                to=""
                class="button button-sm color-blue w-100 bg-blue-op-20"
                >বিড করুন
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      <!-- cate nilam end  -->
    </b-row>
  </b-container>
</template>


<script>
export default {};
</script>
<style >
.nilam-price-cate {
  display: flex;
  height: 73px !important;
}
.nilam-price-cate .item {
  width: 50%;
}
.nilam-price-cate .item:first-child {
  margin-right: 10px;
}
.nilam-hrbid-cate span.item {
  font-size: 15px !important;
}
</style>

