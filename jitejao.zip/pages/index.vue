<template>
  <div>
    <!-- import hero-area  -->
    <HeroArea />
    <CategoryList />
    <!-- <HowToDemand /> -->
    <FeaturesDemand />
    <!-- <FeaturesNilam /> -->
    <!-- <VedioPopup /> -->
    <!--<HomeCategory />-->
    <FeaturesContent />
      <FeaturesContent2 />
              <CounterUser />
    <Testimonial />
    <!-- <AppDownload /> -->

    <Footer />
  </div>
</template>     

<script>
import VedioPopup from "../components/home/VedioPopup.vue";
export default {
  components: { VedioPopup }
};
</script>

<style >
</style>
