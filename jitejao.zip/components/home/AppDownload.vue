<template>
        <div class="clearfix p50  bg-blue-gray">
      <b-container>
         <div class="col-md-6">
           <div class="app-download">
               <div class="content">
                 <h2>Download bido App and get 50 points free!</h2>
                 <p class="mt-10">Use Coupon: <span class="coupon-appdownload bg-purple color-white">DigitalBangladesh</span></p>
               </div>
           </div>
         </div>
           <div class="col-md-6">
                <div class="app-icon mt-30 float-right">
                        <NuxtLink to="/"><img src="~/assets/images/play-store.png" class="img-fluid" alt="play-store" width="150"></NuxtLink>
                        <NuxtLink to="/"><img src="~/assets/images/app-store.png" class="img-fluid ml-15" alt="play-store" width="150"></NuxtLink>
               </div>
           </div>

      </b-container>
    </div>
</template>